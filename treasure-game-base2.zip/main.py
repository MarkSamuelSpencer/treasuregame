print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/_____ /
*******************************************************************************
''')
print("Welcome to Treasure Island.")
print("Your mission is to find the treasure.") 

#https://www.draw.io/?lightbox=1&highlight=0000ff&edit=_blank&layers=1&nav=1&title=Treasure%20Island%20Conditional.drawio#Uhttps%3A%2F%2Fdrive.google.com%2Fuc%3Fid%3D1oDe4ehjWZipYRsVfeAx2HyB7LCQ8_Fvi%26export%3Ddownload

#Write your code below this line 👇
trail = input("As you're following a trail you come accross a fork in the road. To your left is a trail leading into a dense forest, and to your right is a trail ending with tall grass. Which way would you like to go? Type 'left' or 'right'\n").lower()

if trail == "left":
  river = input("As the sun begins to rise you can see a break in the trees. Beyond the break is a wide river, with a short dock large enough to harbor a paddleboat. There is a sign on the dock that says 'Be back at after sunrise.' Are you going to swim or wait and hope to use the boat? Type 'swim' or 'wait'\n").lower()
  if river == "wait":
    village = input("An old withered man approaches the dock with a grim look on his face. He sees you from the river and grunts. 'What do you want?' asks the old man. You tell him you need to cross the river and would like to borrow his boat. He eyes you up and down, replying 'How about a trade then? That's an awfully fine watch you're wearing, son.' You sigh and hand him the watch as he comes ashore. He hands you the paddle, with an ear to ear grin. 'Good Luck.' After reaching the other side of the river you can see smoke coming from downriver. Sure sign of a village. Would you like to visit the village or avoid them? Type 'visit' or 'avoid'\n").lower()
    if village == "avoid":
      doors = input("Upstream you see a large mansion with three entrances. One red door, one blue door, and one yellow door. Which door are you going to enter? Type 'red' 'blue' or 'yellow'\n").lower()
      if doors == "yellow":
        print("You walk slowly up to the yellow door press your ear against the door. Silence. You decide to risk it and pick the lock. As the door creaks open, You're blinded by thousands of small reflections. You rub your eyes, and you can't believe it. You've found the treasure! You Win.")
      elif doors == "blue":
        print("You walk slowly up to the blue door press your ear against the door. Silence. You decide to risk it and pick the lock. Sunlight bursts into the room and you see the shadow of a treasure chest! You run into the room with excitement and the door slams shut behind you. Overhead Lights turn on and gas begins pouring into the room from every direction. Feeling lightheaded you fall to your knees, begin coughing blood, and keel over. Game Over.")
      else:
        print("You walk slowly up to the red door press your ear against the door. Silence. You decide to risk it and pick the lock. You creep into the dark room towards what seems to be a large chest. Upon being opened, the chest begins to tick. You run towards the door and it shuts in front of you as the chest explodes. Game Over.")
    else:
      print("Upon nearing the village you can hear tribal chanting. Maybe they can help with information about the treasure! Entering the village you are welcomed by the tribesmen in broken english. 'Friend. Come. It is time eat.' While he is talking two large men approach from behind and knock you out. You awaken while being tied to a rotisserie skewer. The tribe are cannibals. Game Over.")
  else:
    print("You dive into the water and begin to swim across. As you cross the middle of the river something brushes against your leg. In a panic you swim as hard as you can, but not fast enough to escape the jaws of a hungry river crocodile. Game Over.")
else:
  print("You've fallen into a sinkhole right beyond the grass and fell to your death. Game Over.")
